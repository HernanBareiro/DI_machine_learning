
Estampillas_Yerba_Mate - v6 20210809 751am
==============================

This dataset was exported via roboflow.ai on August 9, 2021 at 11:19 AM GMT

It includes 466 images.
Estamp are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Random rotation of between -28 and +28 degrees
* Random brigthness adjustment of between -14 and +14 percent


